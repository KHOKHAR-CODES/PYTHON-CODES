# Display a welcome header for the calculator program
print("=== Basic Python Calculator ===")

# Start an infinite loop to keep running the calculator until the user chooses to quit
while True:
    # Display the available operations and quit option to the user
    print("\nOperations: +, -, *, / (or type 'q' to quit)")
    
    # Prompt user for input and strip any extra surrounding whitespace
    op = input("Enter operation: ").strip()

    # Check if the user wants to exit the application
    if op.lower() == 'q':
        print("Goodbye!")
        break  # Exit the while loop

    # Validate if the entered operation is one of the supported arithmetic operators
    if op in ('+', '-', '*', '/'):
        # Get numerical inputs from the user and convert them to floating-point numbers
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        # Perform the selected arithmetic operation based on user choice
        if op == '+':
            print("Result:", num1 + num2)
        elif op == '-':
            print("Result:", num1 - num2)
        elif op == '*':
            print("Result:", num1 * num2)
        elif op == '/':
            # Check for division by zero to prevent a runtime ZeroDivisionError
            if num2 == 0:
                print("Error: Cannot divide by zero!")
            else:
                print("Result:", num1 / num2)
    else:
        # Handle cases where the user inputs an unrecognized operator or command
        print("Invalid operation! Choose +, -, *, / or 'q'.")